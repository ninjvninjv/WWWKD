<?php

return [
    'debug' => true,
];
