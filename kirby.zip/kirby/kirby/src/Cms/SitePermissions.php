<?php

namespace Kirby\Cms;

class SitePermissions extends ModelPermissions
{
    protected $category = 'site';
}
